﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Airline_System.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
namespace Airline_System.Data
{
    public class ContextCS : IdentityDbContext
    {
        public ContextCS(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Admin> Admin { get; set; }

        public DbSet<User> User { get; set; }

        public DbSet<Aeroplane> Aeroplane { get; set; }

        public DbSet<FlightBooking> FlightBooking { get; set; }

        public DbSet<Ticket_Reservation> Ticket_Reservation { get; set; }
    }
}
