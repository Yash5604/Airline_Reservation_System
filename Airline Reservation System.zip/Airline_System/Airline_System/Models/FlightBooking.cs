﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Airline_System.Models
{
    [Table("FlightBookingRelation")]
    public class FlightBooking
    {
        [Key]
        public int Bid { get; set; }

        [Required, Display(Name = " Customer Name ")]
        public String customName { get; set; }

        [Required, Display(Name = " Customer Address ")]
        public String customAddress { get; set; }

        [Required, Display(Name = " Customer Email ")]
        public String customEmail { get; set; }

        [Required, Display(Name = " Number of seats ")]
        public String customSeats { get; set; }

        [Required, Display(Name = " Phone Number ")]
        public String customPhone { get; set; }

        [Required, Display(Name = " CNIC no ")]
        public string CnicNo { get; set; }

    }
}
