﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Airline_System.Models
{
    public class Ticket_Reservation
    {
        [Key]
        public int ResId { get; set; }

        [Required, Display(Name ="From City: ")]
        public string resFrom { get; set; }

        [Required, Display(Name = "To City: ")]
        public string resTo { get; set; }

        [Required, Display(Name = "Departure Date ")]
        public string resDepDate { get; set; }

        [Required, Display(Name = "Flight Time ")]
        public string resTime { get; set; }

        [Required, Display(Name = "Plane No")]
        public int PlaneId { get; set; }

        [Required, Display(Name = "Seats Available")]
        public int PlaneSeat { get; set; }

        public float PlaneTicketPrice { get; set; }

        [Required, Display(Name ="Plane Type")]
        public string PlaneType {  get; set; }


    }
}
