﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


namespace Airline_System.Models
{
    [Table("AeroplaneInfo")]
    public class Aeroplane
    {
        [Key]
        public int PlaneID { get; set; }

        [Required(ErrorMessage = "Aeroplane Name is required")]
        [Display(Name = "Aeroplane Name")]
        [MinLength(3, ErrorMessage = "can not be less than three characters"), MaxLength(20, ErrorMessage = "can not be more than 20 characters")]
        public string AeroplaneName { get; set; }

        [Required(ErrorMessage = "Capacity Required")]
        [Display(Name = "Seating Capacity")]
        public int SeatingCapacity { get; set; }

        [Required(ErrorMessage = "Price Required")]
        [Display(Name = "Price")]
        public float Price { get; set; }

    }

}
