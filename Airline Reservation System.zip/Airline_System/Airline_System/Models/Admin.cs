﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Airline_System.Models
{
    [Table("AdminRelation")]
    public class Admin
    {
        [Key]
        public int AdminId { get; set; }

        [Required(ErrorMessage = "Username is required")]
        [Display(Name = "Username")]
        [MinLength(3, ErrorMessage = "username can not be less than 4 characters"), MaxLength(20, ErrorMessage = "username can not be more than 20 characters")]
        public string AdminName { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        [MinLength(5, ErrorMessage = "minimum 5 characters are required"), MaxLength(20, ErrorMessage = "password can not be more than 20 characters")]
        public string Password { get; set; }


    }
}
