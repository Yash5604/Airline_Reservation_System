﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Airline_System.Models
{
    [Table("UserRelation")]
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Firstname is required")]
        [Display(Name = "FirstName")]
        [MinLength(1, ErrorMessage = "fisrtname can not be less than 4 characters"), MaxLength(20, ErrorMessage = "firstname can not be more than 20 characters")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Lastname is required")]
        [Display(Name = "LastName")]
        [MinLength(1, ErrorMessage = "lastname can not be less than 4 characters"), MaxLength(20, ErrorMessage = "lastname can not be more than 20 characters")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email Id is required")]
        [Display(Name = "Email ID")]
        [DataType(DataType.EmailAddress)]
        public string EmailId { get; set; }

        [Required(ErrorMessage = "Username is required")]
        [Display(Name = "UserName")]
        [MinLength(3, ErrorMessage = "username can not be less than 4 characters"), MaxLength(20, ErrorMessage = "username can not be more than 20 characters")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        [MinLength(5, ErrorMessage = "minimum 5 characters are required"), MaxLength(20, ErrorMessage = "password can not be more than 20 characters")]
        public string Password { get; set; }

        [Display(Name = "Confirm Password")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Password not matched")]
        [MinLength(5, ErrorMessage = "minimum 5 characters are required"), MaxLength(20, ErrorMessage = "password can not be more than 20 characters")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Age is required")]
        [Range(18, 120, ErrorMessage = "Minimum age having person 18 can book the flight ticket")]
        public int Age { get; set; }

        [Display(Name = "Phone No")]
        [Required(ErrorMessage = "Phone No is required")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Phone no is not valid")]
        [StringLength(11)]
        public string phoneno { get; set; }

    }
}
