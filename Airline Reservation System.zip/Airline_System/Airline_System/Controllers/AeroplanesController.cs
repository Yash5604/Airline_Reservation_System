﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Airline_System.Data;
using Airline_System.Models;
using Microsoft.AspNetCore.Authorization;

namespace Airline_System.Controllers
{
    [Authorize]
    public class AeroplanesController : Controller
    {
        private ContextCS _context;

        public AeroplanesController(ContextCS context)
        {
            _context = context;
        }

        // GET: Aeroplanes
        public async Task<IActionResult> Index()
        {
              return _context.Aeroplane != null ? 
                          View(await _context.Aeroplane.ToListAsync()) :
                          Problem("Entity set 'ContextCS.Aeroplane'  is null.");
        }

        // GET: Aeroplanes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Aeroplane == null)
            {
                return NotFound();
            }

            var aeroplane = await _context.Aeroplane
                .FirstOrDefaultAsync(m => m.PlaneID == id);
            if (aeroplane == null)
            {
                return NotFound();
            }

            return View(aeroplane);
        }

        // GET: Aeroplanes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Aeroplanes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PlaneID,AeroplaneName,SeatingCapacity,Price")] Aeroplane aeroplane)
        {
            if (ModelState.IsValid)
            {
                _context.Add(aeroplane);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(aeroplane);
        }

        // GET: Aeroplanes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Aeroplane == null)
            {
                return NotFound();
            }

            var aeroplane = await _context.Aeroplane.FindAsync(id);
            if (aeroplane == null)
            {
                return NotFound();
            }
            return View(aeroplane);
        }

        // POST: Aeroplanes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PlaneID,AeroplaneName,SeatingCapacity,Price")] Aeroplane aeroplane)
        {
            if (id != aeroplane.PlaneID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(aeroplane);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AeroplaneExists(aeroplane.PlaneID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(aeroplane);
        }

        // GET: Aeroplanes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Aeroplane == null)
            {
                return NotFound();
            }

            var aeroplane = await _context.Aeroplane
                .FirstOrDefaultAsync(m => m.PlaneID == id);
            if (aeroplane == null)
            {
                return NotFound();
            }

            return View(aeroplane);
        }

        // POST: Aeroplanes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Aeroplane == null)
            {
                return Problem("Entity set 'ContextCS.Aeroplane'  is null.");
            }
            var aeroplane = await _context.Aeroplane.FindAsync(id);
            if (aeroplane != null)
            {
                _context.Aeroplane.Remove(aeroplane);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AeroplaneExists(int id)
        {
          return (_context.Aeroplane?.Any(e => e.PlaneID == id)).GetValueOrDefault();
        }
    }
}
