﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Airline_System.Data;
using Airline_System.Models;
using Microsoft.AspNetCore.Authorization;

namespace Airline_System.Controllers
{
    [Authorize]
    public class FlightBookingsController : Controller
    {
        private readonly ContextCS _context;

        public FlightBookingsController(ContextCS context)
        {
            _context = context;
        }

        // GET: FlightBookings
        public async Task<IActionResult> Index()
        {
              return _context.FlightBooking != null ? 
                          View(await _context.FlightBooking.ToListAsync()) :
                          Problem("Entity set 'ContextCS.FlightBooking'  is null.");
        }

        // GET: FlightBookings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.FlightBooking == null)
            {
                return NotFound();
            }

            var flightBooking = await _context.FlightBooking
                .FirstOrDefaultAsync(m => m.Bid == id);
            if (flightBooking == null)
            {
                return NotFound();
            }

            return View(flightBooking);
        }

        // GET: FlightBookings/Create
        [AllowAnonymous]
        public IActionResult Create()
        {
            return View();
        }

        // POST: FlightBookings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Bid,customName,customAddress,customEmail,customSeats,customPhone,CnicNo,ResId")] FlightBooking flightBooking)
        {
            if (ModelState.IsValid)
            {
                _context.Add(flightBooking);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: FlightBookings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.FlightBooking == null)
            {
                return NotFound();
            }

            var flightBooking = await _context.FlightBooking.FindAsync(id);
            if (flightBooking == null)
            {
                return NotFound();
            }
            return View(flightBooking);
        }

        // POST: FlightBookings/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Bid,customName,customAddress,customEmail,customSeats,customPhone,CnicNo,ResId")] FlightBooking flightBooking)
        {
            if (id != flightBooking.Bid)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(flightBooking);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FlightBookingExists(flightBooking.Bid))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(flightBooking);
        }

        // GET: FlightBookings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.FlightBooking == null)
            {
                return NotFound();
            }

            var flightBooking = await _context.FlightBooking
                .FirstOrDefaultAsync(m => m.Bid == id);
            if (flightBooking == null)
            {
                return NotFound();
            }

            return View(flightBooking);
        }

        // POST: FlightBookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.FlightBooking == null)
            {
                return Problem("Entity set 'ContextCS.FlightBooking'  is null.");
            }
            var flightBooking = await _context.FlightBooking.FindAsync(id);
            if (flightBooking != null)
            {
                _context.FlightBooking.Remove(flightBooking);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FlightBookingExists(int id)
        {
          return (_context.FlightBooking?.Any(e => e.Bid == id)).GetValueOrDefault();
        }
    }
}
