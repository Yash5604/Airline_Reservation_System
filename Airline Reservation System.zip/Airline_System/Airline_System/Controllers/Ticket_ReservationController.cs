﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Airline_System.Data;
using Airline_System.Models;
using Microsoft.AspNetCore.Authorization;

namespace Airline_System.Controllers
{
    [Authorize]
    public class Ticket_ReservationController : Controller
    {
        private readonly ContextCS _context;

        public Ticket_ReservationController(ContextCS context)
        {
            _context = context;
        }

        // GET: Ticket_Reservation
        public async Task<IActionResult> Index()
        {
              return _context.Ticket_Reservation != null ? 
                          View(await _context.Ticket_Reservation.ToListAsync()) :
                          Problem("Entity set 'ContextCS.Ticket_Reservation'  is null.");
        }

        // GET: Ticket_Reservation/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Ticket_Reservation == null)
            {
                return NotFound();
            }

            var ticket_Reservation = await _context.Ticket_Reservation
                .FirstOrDefaultAsync(m => m.ResId == id);
            if (ticket_Reservation == null)
            {
                return NotFound();
            }

            return View(ticket_Reservation);
        }

        // GET: Ticket_Reservation/Create
        [AllowAnonymous]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Ticket_Reservation/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ResId,resFrom,resTo,resDepDate,resTime,planeId,PlaneSeat,PlaneTicketPrice,PlaneType")] Ticket_Reservation ticket_Reservation)
        {
            if (ModelState.IsValid)
            {
                _context.Add(ticket_Reservation);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: Ticket_Reservation/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Ticket_Reservation == null)
            {
                return NotFound();
            }

            var ticket_Reservation = await _context.Ticket_Reservation.FindAsync(id);
            if (ticket_Reservation == null)
            {
                return NotFound();
            }
            return View(ticket_Reservation);
        }

        // POST: Ticket_Reservation/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ResId,resFrom,resTo,resDepDate,resTime,planeId,PlaneSeat,PlaneTicketPrice,PlaneType")] Ticket_Reservation ticket_Reservation)
        {
            if (id != ticket_Reservation.ResId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(ticket_Reservation);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!Ticket_ReservationExists(ticket_Reservation.ResId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(ticket_Reservation);
        }

        // GET: Ticket_Reservation/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Ticket_Reservation == null)
            {
                return NotFound();
            }

            var ticket_Reservation = await _context.Ticket_Reservation
                .FirstOrDefaultAsync(m => m.ResId == id);
            if (ticket_Reservation == null)
            {
                return NotFound();
            }

            return View(ticket_Reservation);
        }

        // POST: Ticket_Reservation/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Ticket_Reservation == null)
            {
                return Problem("Entity set 'ContextCS.Ticket_Reservation'  is null.");
            }
            var ticket_Reservation = await _context.Ticket_Reservation.FindAsync(id);
            if (ticket_Reservation != null)
            {
                _context.Ticket_Reservation.Remove(ticket_Reservation);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool Ticket_ReservationExists(int id)
        {
          return (_context.Ticket_Reservation?.Any(e => e.ResId == id)).GetValueOrDefault();
        }
    }
}
