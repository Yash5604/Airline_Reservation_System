﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Airline_System.Migrations
{
    /// <inheritdoc />
    public partial class newuserrole : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
