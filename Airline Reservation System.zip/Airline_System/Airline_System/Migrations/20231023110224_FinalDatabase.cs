﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Airline_System.Migrations
{
    /// <inheritdoc />
    public partial class FinalDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FlightBookingRelation_AeroplaneInfo_PlaneInfoPlaneID",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "DepartureDate",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "FromCity",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "SeatType",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "ToCity",
                table: "FlightBookingRelation");

            migrationBuilder.RenameColumn(
                name: "PlaneInfoPlaneID",
                table: "FlightBookingRelation",
                newName: "ticketreserveResId");

            migrationBuilder.RenameColumn(
                name: "PlaneId",
                table: "FlightBookingRelation",
                newName: "ResId");

            migrationBuilder.RenameColumn(
                name: "DepartureTime",
                table: "FlightBookingRelation",
                newName: "customSeats");

            migrationBuilder.RenameIndex(
                name: "IX_FlightBookingRelation_PlaneInfoPlaneID",
                table: "FlightBookingRelation",
                newName: "IX_FlightBookingRelation_ticketreserveResId");

            migrationBuilder.AddColumn<string>(
                name: "CnicNo",
                table: "FlightBookingRelation",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "customAddress",
                table: "FlightBookingRelation",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "customEmail",
                table: "FlightBookingRelation",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "customName",
                table: "FlightBookingRelation",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "customPhone",
                table: "FlightBookingRelation",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "Ticket_Reservation",
                columns: table => new
                {
                    ResId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    resFrom = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    resTo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    resDepDate = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    resTime = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    planeId = table.Column<int>(type: "int", nullable: false),
                    aeroplanePlaneID = table.Column<int>(type: "int", nullable: false),
                    PlaneSeat = table.Column<int>(type: "int", nullable: false),
                    PlaneTicketPrice = table.Column<float>(type: "real", nullable: false),
                    PlaneType = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ticket_Reservation", x => x.ResId);
                    table.ForeignKey(
                        name: "FK_Ticket_Reservation_AeroplaneInfo_aeroplanePlaneID",
                        column: x => x.aeroplanePlaneID,
                        principalTable: "AeroplaneInfo",
                        principalColumn: "PlaneID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Ticket_Reservation_aeroplanePlaneID",
                table: "Ticket_Reservation",
                column: "aeroplanePlaneID");

            migrationBuilder.AddForeignKey(
                name: "FK_FlightBookingRelation_Ticket_Reservation_ticketreserveResId",
                table: "FlightBookingRelation",
                column: "ticketreserveResId",
                principalTable: "Ticket_Reservation",
                principalColumn: "ResId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FlightBookingRelation_Ticket_Reservation_ticketreserveResId",
                table: "FlightBookingRelation");

            migrationBuilder.DropTable(
                name: "Ticket_Reservation");

            migrationBuilder.DropColumn(
                name: "CnicNo",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "customAddress",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "customEmail",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "customName",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "customPhone",
                table: "FlightBookingRelation");

            migrationBuilder.RenameColumn(
                name: "ticketreserveResId",
                table: "FlightBookingRelation",
                newName: "PlaneInfoPlaneID");

            migrationBuilder.RenameColumn(
                name: "customSeats",
                table: "FlightBookingRelation",
                newName: "DepartureTime");

            migrationBuilder.RenameColumn(
                name: "ResId",
                table: "FlightBookingRelation",
                newName: "PlaneId");

            migrationBuilder.RenameIndex(
                name: "IX_FlightBookingRelation_ticketreserveResId",
                table: "FlightBookingRelation",
                newName: "IX_FlightBookingRelation_PlaneInfoPlaneID");

            migrationBuilder.AddColumn<DateTime>(
                name: "DepartureDate",
                table: "FlightBookingRelation",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "FromCity",
                table: "FlightBookingRelation",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "SeatType",
                table: "FlightBookingRelation",
                type: "nvarchar(25)",
                maxLength: 25,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ToCity",
                table: "FlightBookingRelation",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddForeignKey(
                name: "FK_FlightBookingRelation_AeroplaneInfo_PlaneInfoPlaneID",
                table: "FlightBookingRelation",
                column: "PlaneInfoPlaneID",
                principalTable: "AeroplaneInfo",
                principalColumn: "PlaneID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
