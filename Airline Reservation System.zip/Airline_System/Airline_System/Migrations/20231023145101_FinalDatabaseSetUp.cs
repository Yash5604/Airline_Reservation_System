﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Airline_System.Migrations
{
    /// <inheritdoc />
    public partial class FinalDatabaseSetUp : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "planeId",
                table: "Ticket_Reservation",
                newName: "PlaneId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "PlaneId",
                table: "Ticket_Reservation",
                newName: "planeId");
        }
    }
}
