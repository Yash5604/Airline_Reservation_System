﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Airline_System.Migrations
{
    /// <inheritdoc />
    public partial class AfterDatabaseSetUp : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FlightBookingRelation_Ticket_Reservation_ticketreserveResId",
                table: "FlightBookingRelation");

            migrationBuilder.DropForeignKey(
                name: "FK_Ticket_Reservation_AeroplaneInfo_aeroplanePlaneID",
                table: "Ticket_Reservation");

            migrationBuilder.DropIndex(
                name: "IX_Ticket_Reservation_aeroplanePlaneID",
                table: "Ticket_Reservation");

            migrationBuilder.DropIndex(
                name: "IX_FlightBookingRelation_ticketreserveResId",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "aeroplanePlaneID",
                table: "Ticket_Reservation");

            migrationBuilder.DropColumn(
                name: "ResId",
                table: "FlightBookingRelation");

            migrationBuilder.DropColumn(
                name: "ticketreserveResId",
                table: "FlightBookingRelation");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "aeroplanePlaneID",
                table: "Ticket_Reservation",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ResId",
                table: "FlightBookingRelation",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ticketreserveResId",
                table: "FlightBookingRelation",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Ticket_Reservation_aeroplanePlaneID",
                table: "Ticket_Reservation",
                column: "aeroplanePlaneID");

            migrationBuilder.CreateIndex(
                name: "IX_FlightBookingRelation_ticketreserveResId",
                table: "FlightBookingRelation",
                column: "ticketreserveResId");

            migrationBuilder.AddForeignKey(
                name: "FK_FlightBookingRelation_Ticket_Reservation_ticketreserveResId",
                table: "FlightBookingRelation",
                column: "ticketreserveResId",
                principalTable: "Ticket_Reservation",
                principalColumn: "ResId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Ticket_Reservation_AeroplaneInfo_aeroplanePlaneID",
                table: "Ticket_Reservation",
                column: "aeroplanePlaneID",
                principalTable: "AeroplaneInfo",
                principalColumn: "PlaneID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
